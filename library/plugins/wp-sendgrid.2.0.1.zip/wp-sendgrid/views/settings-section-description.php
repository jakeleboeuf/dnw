<p>
	<?php _e( 'You need a SendGrid account to send emails with the SendGrid API.' ); ?>
</p>
<p>
	<?php printf( __( 'If you don\'t have an account, you should <a href="%s" target="_blank">sign up for one</a>.' ), 'https://sendgrid.com/user/signup' ); ?>
</p>